# CITY_CORDINATES
This is an app which tells the latitude and longitude of their desired city.
